<script setup>
//import MyStyleComp from './components/MyStyleComp.vue'
//import StyleComp from './components/StyleComp.vue'
//import VshowEx from './components/VshowEx.vue'
//import VifEx from './components/VifEx.vue'
//import Employee from './components/Employee.vue'
//import CompAPI from './components/ReactiveEx1.vue' 
//import ReactiveComp from './components/ReactiveEx2.vue'
import Lifecycle from './components/Lifecycle.vue'
</script>

<template>
  <div>
    <!-- <my-style-comp/> -->
    <!-- <style-comp/> -->
    <!-- <vshow-ex/> -->
    <!-- <vif-ex/> -->
    <!-- <employee/> -->
    <!-- <CompAPI/> -->
    <!-- <ReactiveComp/> -->
    <lifecycle/>
  </div>
</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
