<template>
    <div>
        <h1>Title is {{title}}</h1>
        <h2>Name is {{data.pname}}</h2>
        <button @click="update">Click</button>
    </div>
</template> 

<script setup>
    import {reactive,ref} from 'vue'
    let title = ref("Welcome to new enhancement in Vue 3")
    let data = reactive({
        pname:"Raj",
        paddress:"Delhi"
    })
    setTimeout(()=>{
        title.value = "Welcome to Vue 3"
        data.pname = "Rahul"
    },3000)
    function update(){
        alert("updated")
    }
</script>