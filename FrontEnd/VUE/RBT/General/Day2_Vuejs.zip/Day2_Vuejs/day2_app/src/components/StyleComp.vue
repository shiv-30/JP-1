<template>
    <div class="container">
        <div class="row">
            <button class="btn btn-primary col-2">Primary</button>
            <button class="btn btn-warning col-3">Warning</button>
            <button class="btn btn-danger col-2">Danger</button>
            <button class="btn btn-info col-3">Info</button>
            <button class="btn btn-success col-2">Success</button>
        </div>
    </div>    
</template>
