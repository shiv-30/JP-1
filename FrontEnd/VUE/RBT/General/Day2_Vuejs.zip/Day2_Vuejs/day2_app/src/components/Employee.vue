<template>
    <ul>
        <li v-for="(emp,index) in employees" :key="emp.id" >
           <!-- <p v-if="emp.eSal>=50000"> -->
           {{index}} {{emp.eName}} {{emp.eSal}}
           <button @click="deleteEmployee(index)">Delete</button>
           <!-- </p> -->

        </li>
    </ul>    
</template>

<script>
export default {
    data(){
        return {
            employees:[
                {
                    id:1,
                    eName:"Kavita",
                    eSal:40000
                },
                {
                    id:2,
                    eName:"Ajay",
                    eSal:50000
                },
                {
                    id:3,
                    eName:"Ram",
                    eSal:60000
                }
            ]
        }
    },
    methods: {
        deleteEmployee(index){
            this.employees.splice(index,1)
        }
    },
}
</script>