<template>
    <div>
        <h1>{{message}}</h1>
        <h2>Count is {{count}}</h2>
        <button @click="count++">Increment</button>
    </div>
    
</template>

<script setup>
    import {ref,onMounted,onUnmounted, onUpdated} from 'vue'

    let message = ref("Hello All")
    let count = ref(1)
    onMounted(()=>{
        setInterval(()=>{
            message.value = "Welcome All"
        },5000)
    })
    onUpdated(()=>{
        alert("count is updated to ",count.value)
    })
    onUnmounted(()=>{clearInterval()})

</script>