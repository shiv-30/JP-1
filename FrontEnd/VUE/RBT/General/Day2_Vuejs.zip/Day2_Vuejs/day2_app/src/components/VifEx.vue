<template>
    <div>
        <h1 v-if="page>=18">You are eligible for voting!!!</h1>
        <h1 v-else-if="page<=0">Not correct age</h1>
        <h1 v-else>Not eligible for voting!!</h1>
    </div>    
</template>

<script>
export default {
    data(){
        return {
            page : 19
        }
    }
}
</script>