<template>
    <div>
        <h1>Title is {{title}}
        </h1>
        <h2>Name is {{data.pname}}</h2>
        </div>
</template>

<script>
    import {reactive,ref} from 'vue'
    export default {
        name:'CompAPI',
        setup() {
            let title = ref("Vue 3 composition API")
            //ref() will return proxy of original object and its added with value prop 
            //on it so to modify title everytime we should use title.value

            let data = reactive({
                id:101,
                pname:"Pooja"
            })
            setTimeout(()=>{
                title.value = "Modified to new value"
                data.pname = "Smita"
            },5000)
            return {title,data}
        }
    }
</script>