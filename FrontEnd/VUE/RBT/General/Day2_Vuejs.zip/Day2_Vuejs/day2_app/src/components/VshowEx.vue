<template>
    <div>
        <label for="showDiv">Show Div</label>
        <input type="checkbox" name="showDiv" @change="update" ref="check"/>
        <div v-show="showDiv">Welcome To Vue.js</div>
    </div>   
</template>
<script>
export default {
    data(){
        return {
            showDiv : false 
        }
    },
    methods: {
       update() {
            this.showDiv = this.$refs.check.checked
       }, 
    },
}
</script>