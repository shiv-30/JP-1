<template>
    <div>
        <div :style="{color:activeColor,fontSize:fontSize+'px'}">
            Applying inline style!!!
        </div>
        <br/>
        <div :style="styleObject">
            Applying inline style using object syntax!!!
        </div>
        <br/>
        <div id="myDiv">
            <p class="para1">This is first paragraph</p>
            <p class="para2">This is second paragraph</p>
        </div>
    </div>    
</template>

<script>
export default {
    data(){
        return {
            activeColor: 'blue',
            fontSize: 30,
            styleObject:{
                color: 'red',
                fontStyle: 'italic',
                fontSize: '40px'
            }
        }
    }
}
</script>
<style>
    #myDiv{
        background-color: aqua;
        height: 300px;
        width: 400px;
    }
    .para1{
        color: magenta;
        font-size: 20px;
    }
    .para2{
        color:darkblue;
        font-size: 30px;
    }
</style>