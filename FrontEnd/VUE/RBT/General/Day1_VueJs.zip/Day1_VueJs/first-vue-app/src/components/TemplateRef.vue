<template>
    <div>
        <label>Enter Name::</label>
        <input type="text" ref="input1"/>
        <br/>
        <input type="text" ref="input2"/>
        <br/>
        <button @click="show">Show Name</button>
    </div>
</template>

<script>
export default {
    methods: {
        show(){
            let val = this.$refs.input1.value
            this.$refs.input2.value = this.$refs.input1.value
            alert("Name is "+val)
        }
    },
}
</script>
