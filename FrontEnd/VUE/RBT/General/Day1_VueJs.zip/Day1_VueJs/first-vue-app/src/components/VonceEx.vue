<template>
    <div>
        <label>Change Text</label>
        <br/>
        <span v-once>{{message}}</span>
        <br/>
        <input type="text" ref="input1"/>
        <br/>
        <button @click="modifyMessage">Modify</button>
    </div>
</template>

<script>
export default {
    data(){
        return {
            message : "Welcome All!!"
        }
    },
    methods: {
      modifyMessage(){
        let val = this.$refs.input1.value
        this.message = val
      }  
    },
}
</script>