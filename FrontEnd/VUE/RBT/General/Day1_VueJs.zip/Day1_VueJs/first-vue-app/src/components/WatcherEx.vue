<template>
    <div>
        <input type="text" ref="input1"/>
        <br/>
        <button @click="updateName">Update Name</button>
        <h1>Hello {{pname}}</h1>
    </div>
</template>
<script>
export default {
    data(){
    return {
        pname : ""
    }    
    },
    methods: {
        updateName(){
            let newName = this.$refs.input1.value
            this.pname = newName 
        }
    },
    watch: {
        pname : function(){
            alert("pname is updated and it is "+this.pname)
        }
    },
}
</script>