<template>
    <div>
        <p>{{message}}</p>
        <p>{{reverseMessage}}</p>
        <input type="text" ref="input1" placeholder="Enter new Message"/>
        <br/>
        <button @click="updateMessage">Update Message</button>
    </div>    
</template>
<script>
    
    export default {
        name:"MyComponent",
        data(){
            return {
                message : "Hello"
            }
        },
        methods: {
            updateMessage(){
                this.message = this.$refs.input1.value
            }
        },
        computed: {
            reverseMessage : function(){
                return this.message.split('').reverse().join('')
            }
        },
        watch:{
            message : function(){
                alert("message is updated to "+this.message)
            }
        }
    }
</script>