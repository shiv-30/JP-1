<script setup>
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup
//import HelloWorld from './components/HelloWorld.vue'
//import MyComp from './components/MyComp.vue'
// import EventComp from './components/EventComp.vue'
// import TemplateRef from './components/TemplateRef.vue'
//import VonceEx from './components/VonceEx.vue'
// import FormEx from './components/FormEx.vue'
// import Hobbies from './components/Hobbies.vue'
//import WatcherEx from './components/WatcherEx.vue'
import MyComponent from './components/Example.vue'
</script>

<template>
  <div>
      <!-- <my-comp/> -->
      <!-- <event-comp/>
      <template-ref/> -->
      <!-- <vonce-ex/> -->
      <!-- <form-ex/>
      <hobbies/> -->
      <!-- <watcher-ex/> -->
      <MyComponent/>
  </div>

</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
