<template>
    <div>
        <p>{{info}}</p>
    <!-- <p>{{message}}</p> -->
    <p v-html="message"></p>
    <!-- to bind state of comp with attribute of html element we need to use another 
    directive from vue i.e. v-bind -->
    <!-- <a v-bind:href="url">Microsoft</a> -->
    <!-- shorthand for it -->
    <a :href="url">Microsoft</a>
    <img :src="`${imgUrl}`"/>
    </div>
</template>

<script>
export default {
    data(){
        return {
            info : "Checking Vue 3 Options API!!!",
            message : '<h1>Hello From Vue3!!!</h1>',
            url:'http://www.microsoft.com',
            imgUrl: 'src/assets/flower1.jpeg'
        }
    }
}
</script>