<template>
    <div>
        <input type="text" v-model="name"/>
        <br/>
        <input type="number" v-model="age"/>
        <br/>
        <h1>Name is {{name}} and age is {{age}}</h1>
    </div>    
</template>

<script>
    export default{
        data(){
            return {
                name : "default",
                age: 0
            }
        }
    }
</script>