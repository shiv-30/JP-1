<template>
    <div>
        <h1>Count is {{count}}</h1>
        <!-- method handler -->
        <button v-on:click="increment">Increment</button>
        <!-- inline handler -->
        <button v-on:click="count--">Decrement</button>
        <!-- increment, increment(9) - this will be considered as method handler
        if increment() - inline handler
         -->
         <button @click="sayHello('Welcome')">Say Hello</button>
    </div>
</template>

<script>
export default {
    data(){
        return {
            count : 10
        }
    },
    methods: {
        increment(){
            this.count++
        },
        sayHello(msg){
            alert("msg is "+msg)
        }
    },    
}
</script>