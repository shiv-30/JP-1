<template>
    <div>
        <!-- without computed prop -->
        <!-- <h1>{{hobbies.length>=3 ? "Great you have many hobbies":"oh so less hobbies"}}
        </h1> -->
        <!-- with computed prop -->
        <h2>{{checkLength}}</h2>
    </div>   
</template>

<script>
export default {
    data(){
        return {
            hobbies : ["Music","Reading","Dance"]
        }
    },
    methods: {
        updateHobbies(){
            let len = this.hobbies.length
            hobbies[len-1] = "Cooking"
        }
    },
    computed: {
        checkLength(){
            return this.hobbies.length>=3? "Great" : "Try some more"
        }
    },
}

</script>