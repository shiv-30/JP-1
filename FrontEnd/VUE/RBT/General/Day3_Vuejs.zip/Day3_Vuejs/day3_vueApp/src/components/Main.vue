<template>
    <div>
        <component :is="CompOne"/>
        <!-- <component :is="showComp==false?CompTwo:CompOne"/> -->
    </div>    
</template>

<script setup>
    import CompOne from './CompOne.vue'
    import CompTwo from './CompTwo.vue'
    let showComp=false

</script>