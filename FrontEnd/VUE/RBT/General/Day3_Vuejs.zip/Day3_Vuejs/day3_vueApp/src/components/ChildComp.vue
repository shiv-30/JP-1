<template>
   <div>
        <h1>Hello From Child Component!!!</h1> 
        <h2>Title received from parent is {{headerTitle}}</h2>
        <!-- To accept new value for title from child comp -->
        <label for="newTitle">Enter new title</label>
        <input type="text" name="newTitle" ref="input1"/>
        <br/>
        <button @click="updateTitle">Update Title</button>
   </div> 
</template>

<script setup>
// to define props here we should use defineProps() from vue
import {defineProps,defineEmits} from 'vue'
import {ref} from 'vue'
let input1 = ref(null)
const emit = defineEmits(['changeTitle'])
const props = defineProps({
    headerTitle : String
})
function updateTitle(){
    let newTitle = input1.value
    //want to modify state title of parent comp with this newTitle
    //trying to pass data from childcomp to parentcomp, to perform this child comp
    //has to emit custom event. To emit custom event we need to use defineEmits()
    //from vue
    emit('changeTitle',newTitle.value)
}
</script>