<template>
    <h1>Rendered Component one!!!</h1>
</template>