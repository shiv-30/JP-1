<template>
    <div>
        <h1>Info is {{info}}</h1>
        <!-- <sub-comp/>     -->
        <!-- when using slots  -->
        <sub-comp>
            <template v-slot:header>
                <h1>Welcome to Slots in Vue3!!!</h1>
            </template>
            <template v-slot:footer>
                <h2>Copyright:2022;Xyz ltd</h2>
            </template>
            <template v-slot>
               <h3> This is something additional from MainComp!!!</h3>
            </template>
        </sub-comp>
    </div>    
</template>

<script setup>
    import SubComp from './SubComp.vue'
    import {ref} from 'vue'

    let info = ref("Trying to check with and without scoped style")
</script>

<style>
    div{
        background-color: lightseagreen;
        color: black;
    }
</style>
