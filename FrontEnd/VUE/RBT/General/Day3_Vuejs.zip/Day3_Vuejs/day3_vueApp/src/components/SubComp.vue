<template>
    <div>
        <header><slot name="header"></slot></header>
        <h1>Message is {{message}}</h1>
        <p><slot></slot></p>
        <footer><slot name="footer"></slot></footer>
    </div>    
</template>

<script setup>
    import {ref} from 'vue'

    let message = ref("Greetings!!")

</script>
<style scoped>
    div{
        height: 300px;
        width:500px;
        background-color: antiquewhite;
        color: brown;
    }

</style>