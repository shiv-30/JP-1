<template>
    <div>
        <h1>Hello From Parent Component!!!</h1>
        <h2>State of Parent title is {{title}}</h2>
        <!-- passing data from parentComp to childComp via props headerTitle
        To access this data in child component child comp must have this props 
        headerTitle -->
        <!-- <child-comp headerTitle="Component Communication"/> -->
        <!-- to bind state of parent with props of child we should 
        use v-bind or : -->
        <!-- event which is emitted by child comp is in camelCase and it need to be handled
        by parent using kabab case conversion -->
        <child-comp :headerTitle="title" @change-title="modifyTitle($event)"/>
    </div>    
</template>

 <script setup>
 
import ChildComp from './ChildComp.vue'
import {ref} from 'vue'

let title = ref("Checking Component Communication!!!")
//to modify title
function modifyTitle(newVal){
    title.value = newVal
}
//  import ChildComp from './ChildComp.vue'
//     export default{
//         components:{
//             ChildComp
//         }
//    }

// import ChildComp from './ChildComp.vue'
//props:['title']
// setup(){
//    return {ChildComp}
// }
 </script>

