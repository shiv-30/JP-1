<template>
    <form @submit="sendData">
        <label for="username">Enter you username</label>
        <input type="text" name="username" v-model="uname"/>

        <br/>
        <label for="password">Enter password</label>
        <input type="password" name="password" v-model="password"/>

        <br/>
        <label for="skill">Select Skill</label>
        <select name="skill" v-model="selected">
            <option value="Java">Java</option>
            <option value="React">React</option>
            <option value="Vue">Vue</option>
        </select>
        <br/>
        <label for="proofs">Select the proofs</label>
        Aadhar::<input type="checkbox" name="proof" value="Aadhar" v-model="proofs"/>
        PAN::<input type="checkbox" name="proof" value="PAN" v-model="proofs"/>
        ID::<input type="checkbox" name="proof" value="ID" v-model="proofs"/>
        <br/>
        <button type="submit">Submit</button>
    </form>
</template>

<script setup>
    import {ref} from 'vue'
    let uname = ref("")
    let password = ref("")
    let selected = ref("")
    let proofs = ref([])
    function sendData(){
        alert("username is "+uname.value+" password is "+password.value+" selected skill is "
        +selected.value)
        alert("proofs "+proofs.value)
    }
</script>